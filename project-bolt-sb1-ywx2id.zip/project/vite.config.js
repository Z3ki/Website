export default {
  base: '/z3ki.github.io/',
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
  }
}